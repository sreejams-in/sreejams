SREEJA M S — ELECTRIC BLUE PORTFOLIO

Files included:
- index.html: page content
- style.css: responsive navy, white and electric-blue design
- script.js: mobile navigation
- README.txt: setup and publishing notes

Before publishing:
1. Replace YOUR_EMAIL@example.com with your real email.
2. Update social links with your real profile URLs.
3. The portrait is a placeholder using your initials, not a real photo. To add your own photo, replace the .portrait div in index.html and style it in style.css.
4. Verify all experience details and campaign metrics before publishing.

Preview: open index.html in a browser.

Free GitHub Pages setup:
1. Create a public repository named YOURUSERNAME.github.io.
2. Upload index.html, style.css and script.js to the repository root.
3. Go to Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
4. Follow the published website link GitHub provides.

This static website does not require paid hosting or a backend. Google Fonts are optional and require an internet connection.
