SREEJA M S — PORTFOLIO STARTER

Files
- index.html: portfolio content and page structure
- style.css: layout, colours, typography, and responsive design

BEFORE PUBLISHING
1. In index.html, replace YOUR_EMAIL@example.com with your professional email.
2. Replace the LinkedIn link href="#" with your real LinkedIn profile URL.
3. Check all claims, especially 3,000+ leads and ₹590 average CPL, and only publish figures you are allowed to share.
4. Update the education and experience details if needed.
5. Do not add private company data, phone numbers, or confidential campaign information.

PUBLISH WITH GITHUB PAGES
1. Create a GitHub account at https://github.com if you do not have one.
2. Create a PUBLIC repository named exactly: YOUR-GITHUB-USERNAME.github.io
   Replace YOUR-GITHUB-USERNAME with your GitHub username.
3. Upload index.html and style.css to the repository root.
4. Open Settings > Pages. Under Build and deployment, select Deploy from a branch,
   choose main and /(root), then Save.
5. Wait for the published URL shown in Settings > Pages.

CONNECT YOUR DOMAIN
Follow the current GitHub Docs for custom domains:
https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site

Important: Add your custom domain in GitHub Pages settings before changing DNS records.
For the apex domain sreejams.in, GitHub currently documents these A records:
185.199.108.153
185.199.109.153
185.199.110.153
185.199.111.153
For www, add a CNAME record pointing to YOUR-GITHUB-USERNAME.github.io.
Delete conflicting A/AAAA/CNAME records for the same host only after reviewing them; do not delete MX records or records used for email.
DNS changes can take up to 24 hours. Enable Enforce HTTPS in Settings > Pages when available.

This is a static portfolio starter, not a form backend. GitHub Pages cannot run server-side PHP or databases.
